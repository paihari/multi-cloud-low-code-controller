package main

import (
	"fmt"

	"golang.org/x/text/language"
)

func main() {
	fmt.Println("hello")
	language.Parse("")
}
