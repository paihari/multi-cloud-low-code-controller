This code was copied from src/debug/gosym in the go repo at commit 29604312784cfbf530fcf54837b7cf42c0500d0b.

It was modified to remove dependencies on internal packages in the go repo,
and to compile under go 1.17.
