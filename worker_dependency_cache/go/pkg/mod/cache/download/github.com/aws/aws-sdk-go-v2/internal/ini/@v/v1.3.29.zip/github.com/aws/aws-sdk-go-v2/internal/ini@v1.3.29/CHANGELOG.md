# v1.3.29 (2023-02-03)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.28 (2022-12-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.27 (2022-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.26 (2022-10-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.25 (2022-10-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.24 (2022-09-20)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.23 (2022-09-14)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.22 (2022-09-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.21 (2022-08-31)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.20 (2022-08-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.19 (2022-08-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.18 (2022-08-09)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.17 (2022-08-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.16 (2022-08-01)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.15 (2022-07-05)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.14 (2022-06-29)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.13 (2022-06-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.12 (2022-05-17)

* **Bug Fix**: Removes the fuzz testing files from the module, as they are invalid and not used.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.11 (2022-04-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.10 (2022-03-30)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.9 (2022-03-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.8 (2022-03-23)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.7 (2022-03-08)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.6 (2022-02-24)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.5 (2022-01-28)

* **Bug Fix**: Fixes the SDK's handling of `duration_sections` in the shared credentials file or specified in multiple shared config and shared credentials files under the same profile. [#1568](https://github.com/aws/aws-sdk-go-v2/pull/1568). Thanks to [Amir Szekely](https://github.com/kichik) for help reproduce this bug.

# v1.3.4 (2022-01-14)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.3 (2022-01-07)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.2 (2021-12-02)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.1 (2021-11-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.3.0 (2021-11-06)

* **Feature**: The SDK now supports configuration of FIPS and DualStack endpoints using environment variables, shared configuration, or programmatically.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.5 (2021-10-21)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.4 (2021-10-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.3 (2021-09-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.2 (2021-08-27)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.1 (2021-08-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.0 (2021-08-04)

* **Feature**: adds error handling for defered close calls
* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.1 (2021-07-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.0 (2021-07-01)

* **Feature**: Support for `:`, `=`, `[`, `]` being present in expression values.

# v1.0.1 (2021-06-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.0.0 (2021-05-20)

* **Release**: The `github.com/aws/aws-sdk-go-v2/internal/ini` package is now a Go Module.
* **Dependency Update**: Updated to the latest SDK module versions

